मेरा Loan Plan v6 — GitHub Pages Ready

Files:
index.html              = Dashboard
loans.html              = My Loans
income.html             = Income & Expense
plan.html               = Debt Freedom Plan
investment.html         = Savings & Investment (future-ready)
assets/style.css        = Common design
assets/app.js           = Common data/calculation logic

IMPORTANT:
1. Upload the complete folder contents to ONE GitHub repository, preserving the assets folder.
2. Open index.html through GitHub Pages.
3. All pages use the same localStorage key: mera_loan_plan_v6.
4. Loan selection uses stable loan IDs, so editing/deleting/tapping the correct loan works even with multiple loan types.
5. Bank Actual and App Calculation are separate; the tapped option becomes Final Amount and is used in Dashboard foreclosure total.
6. This is a client-side prototype. No bank credentials, OTP, PIN, or live bank connection is used.
